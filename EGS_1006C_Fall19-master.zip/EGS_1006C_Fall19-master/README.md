# EGS_1060C_fall19
#

## Installing Code Composer SimpleLink module

An extra module needs to be installed to use the Driverlib library.

1. Select **View -> Resource Explorer**
2. Select Folder **Software -> SimpleLink MSP432P4 SDK -v:2.30.00.14**
3. Select the icon: **Download and Install**
